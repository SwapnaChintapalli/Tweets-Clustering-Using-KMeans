CS 6375.003 Machine Learning
Assignment 4: Supervised learning Problems
Group Memebers:
Swapna Chintapalli - SXC180048
Pallavi Pandey - PXP170009

Compilation Steps:
1. Open TweetsCluster.py in Python IDE.
2. Run TweetsCluster.py
3. Check console and enter the inputs
tweets-k-means <numberOfClusters> <initialSeedsFile> <TweetsDataFile> <outputFile>
ex: tweets-k-means 25 InitialSeeds.txt Tweets.json tweets-k-means-output.txt
4.Check tweets-k-means-output.txt for output.