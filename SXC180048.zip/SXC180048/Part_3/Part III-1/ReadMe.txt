CS 6375.003 Machine Learning
Assignment 4: Supervised learning Problems
Group Memebers:
Swapna Chintapalli - SXC180048
Pallavi Pandey - PXP170009

Compilation Steps:
1. Open ColorQuantization.py in Google Colaboratory.
2. Upload images to Files
3. Change image_filename and no_of_clusters to required image and k-value in the code.
4. Run ColorQuantization.py
5. Check output image quality and size.

