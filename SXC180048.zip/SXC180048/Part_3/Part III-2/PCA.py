#CS 6375.003 Machine Learning
#Assignment 4: Supervised learning Problems
#Group Members:
#SXC180048- Swapna Chintapalli
#PXP170009- Pallavi Pandey

from numpy import *
from matplotlib import *
from skimage import img_as_float
import imageio
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import numpy as np
from sklearn.preprocessing import MinMaxScaler

image_filename = 'image1.jpg'
img = imageio.imread(image_filename)
print(img.shape)
plt.axis('off') 
plt.imshow(img)
print('\n')

img_r = np.reshape(img, (img.shape[0], img.shape[1]*3))
print(img_r.shape)
pca_values= 10
ipca = PCA(pca_values).fit(img_r) 
img_c = ipca.transform(img_r) 
print(img_c.shape)
print(np.sum(ipca.explained_variance_ratio_))
plt.imshow(img)

temp = ipca.inverse_transform(img_c) 
print(temp.shape)
scaling = MinMaxScaler(feature_range=(0, 1))
scaling.fit(temp)
temp = scaling.transform(temp)
temp= temp.reshape(img.shape[0], img.shape[1],3)
print(temp.shape)

# plt.axis('off')
plt.imshow(temp)
