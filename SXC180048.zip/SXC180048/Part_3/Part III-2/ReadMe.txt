CS 6375.003 Machine Learning
Assignment 4: Supervised learning Problems
Group Memebers:
Swapna Chintapalli - SXC180048
Pallavi Pandey - PXP170009

Compilation Steps:
1. Open PCA.pyin Google Colaboratory.
2. Upload images to Files
3. Change image_filename and pca_values to required image and PCA value in the code.
4. Run PCA.py
5. Check output image quality and size.

